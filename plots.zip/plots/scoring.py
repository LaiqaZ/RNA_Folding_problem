import os
import numpy as np

class RNAGibbsFreeEnergyCalculator:
    def __init__(self, scores_folder, distance_threshold=20, sequence_threshold=4):
        self.scores_folder = scores_folder
        self.distance_threshold = distance_threshold
        self.sequence_threshold = sequence_threshold
        self.distance_bins = np.linspace(0, distance_threshold, 21)
        self.scores = self.load_scores()

    def load_scores(self):
        """Load precomputed scores for all base pairs."""
        scores = {}
        for file_name in os.listdir(self.scores_folder):
            if file_name.endswith("_scores.txt"):
                base_pair = file_name.replace("_scores.txt", "")
                with open(os.path.join(self.scores_folder, file_name), 'r') as f:
                    scores[base_pair] = np.array([float(line.strip()) for line in f.readlines()])
        return scores

    def interpolate_score(self, base_pair, distance):
        """Perform linear interpolation for the score."""
        if base_pair not in self.scores:
            return 10  # Arbitrary high score for missing base pairs

        bin_edges = self.distance_bins
        bin_scores = self.scores[base_pair]
        
        if distance < bin_edges[0] or distance > bin_edges[-1]:
            return 10  # Maximum score for out-of-range distances

        bin_index = np.digitize(distance, bin_edges) - 1
        if bin_index >= len(bin_scores) - 1:
            return bin_scores[-1]

        # Linear interpolation
        r1, r2 = bin_edges[bin_index], bin_edges[bin_index + 1]
        s1, s2 = bin_scores[bin_index], bin_scores[bin_index + 1]
        return s1 + (distance - r1) * (s2 - s1) / (r2 - r1)

    def parse_pdb(self, pdb_file):
        """Parse the PDB file and extract C3' atoms and coordinates."""
        atoms = []
        with open(pdb_file, 'r') as file:
            for line in file:
                if line.startswith("ATOM") and " C3' " in line:
                    res_name = line[17:20].strip()
                    coord = (
                        float(line[30:38]),
                        float(line[38:46]),
                        float(line[46:54])
                    )
                    atoms.append((res_name, coord))
        return atoms

    def compute_gibbs_free_energy(self, pdb_file):
        """Compute the estimated Gibbs free energy for the RNA structure."""
        atoms = self.parse_pdb(pdb_file)
        total_score = 0

        for i, (res1, coord1) in enumerate(atoms):
            for j, (res2, coord2) in enumerate(atoms):
                if abs(i - j) < self.sequence_threshold:
                    continue

                distance = np.linalg.norm(np.array(coord1) - np.array(coord2))
                if distance > self.distance_threshold:
                    continue

                base_pair = res1[0] + res2[0]
                score = self.interpolate_score(base_pair, distance)
                total_score += score

        return total_score

# Main function to compute Gibbs free energy
def main():
    scores_folder = "scores"
    pdb_file = "input_structure.pdb"  # Replace with your PDB file path

    calculator = RNAGibbsFreeEnergyCalculator(scores_folder)
    gibbs_free_energy = calculator.compute_gibbs_free_energy(pdb_file)

    print(f"Estimated Gibbs free energy: {gibbs_free_energy}")

if __name__ == "__main__":
    main()
